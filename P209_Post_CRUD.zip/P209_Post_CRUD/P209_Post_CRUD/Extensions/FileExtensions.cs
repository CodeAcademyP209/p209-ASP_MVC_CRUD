﻿using System;
using System.Web;
using System.IO;

namespace P209_Post_CRUD.Extensions
{
    public static class FileExtensions
    {
        public static bool IsImage(this HttpPostedFileBase file)
        {
            return file.ContentType == "image/jpg" ||
                   file.ContentType == "image/jpeg" ||
                   file.ContentType == "image/png" ||
                   file.ContentType == "image/gif";
        }

        public static string Save(this HttpPostedFileBase image, string subfolder)
        {
            string newFilename = subfolder + @"\" + Guid.NewGuid().ToString() + Path.GetFileName(image.FileName);

            string fullPath = Path.Combine(HttpContext.Current.Server.MapPath("~/Uploads"), newFilename);

            image.SaveAs(fullPath);

            return newFilename;
        }
    }
}