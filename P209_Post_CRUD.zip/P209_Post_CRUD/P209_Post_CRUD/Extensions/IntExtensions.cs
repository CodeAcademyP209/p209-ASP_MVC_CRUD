﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace P209_Post_CRUD
{
    public static class IntExtensions
    {
        public static int Power(this int powerBase, int power)
        {
            return (int)Math.Pow(powerBase, power);
        }
    }
}