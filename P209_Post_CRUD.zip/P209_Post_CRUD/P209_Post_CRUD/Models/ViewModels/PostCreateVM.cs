﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace P209_Post_CRUD.Models.ViewModels
{
    public class PostCreateVM
    {
        public Post Post { get; set; }
        public IEnumerable<Author> Authors { get; set; }
    }
}