﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace P209_Post_CRUD.Models
{
    public class Post
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Title can not be empty"), StringLength(200, ErrorMessage = "Title can not be longer than 200 characters")]
        public string Title { get; set; }

        [Required]
        [MinLength(5)]
        public string Content { get; set; }

        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        public int ViewCount { get; set; }

        [StringLength(300)]
        public string Image { get; set; }

        //public virtual ICollection<Image> Images { get; set; }

        [NotMapped]
        public HttpPostedFileBase Photo { get; set; }

        public int AuthorId { get; set; }

        public virtual Author Author { get; set; }
    }
}