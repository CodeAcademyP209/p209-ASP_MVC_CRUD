﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P209_Post_CRUD.Models;
using P209_Post_CRUD.DAL;


namespace P209_Post_CRUD.Controllers
{
    public class AuthorsController : Controller
    {
        private readonly BlogContext _context;

        public AuthorsController()
        {
            _context = new BlogContext();
        }

        [Route("Authors/{id}")]
        public ActionResult AuthorById(int? id)
        {
            if (id == null) return HttpNotFound();

            var author = _context.Authors.Find(id);

            if(author == null) return HttpNotFound();

            return View(author);
        }
    }
}