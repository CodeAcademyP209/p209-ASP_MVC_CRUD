﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P209_Post_CRUD.DAL;
using P209_Post_CRUD.Models;
using System.Data.Entity;


namespace P209_Post_CRUD.Controllers
{
    public class HomeController : Controller
    {
        private readonly BlogContext _context;

        public HomeController()
        {
            _context = new BlogContext();
        }

        public ActionResult Index()
        {
            var posts = _context.Posts.OrderByDescending(p => p.CreatedAt).ToList();
            return View(posts);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}