﻿using P209_Post_CRUD.Models;
using P209_Post_CRUD.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using P209_Post_CRUD.Extensions;
using P209_Post_CRUD.DAL;
using System.Data.Entity;
using static P209_Post_CRUD.Utilities.Utilities;

namespace P209_Post_CRUD.Controllers
{
    public class PostsController : Controller
    {
        private readonly BlogContext _context;

        public PostsController()
        {
            _context = new BlogContext();
        }

        // GET: Posts
        public ActionResult Create()
        {
            var vm = new PostCreateVM
            {
                Authors = _context.Authors,
                Post = new Post()
            };
            
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Title, Content, AuthorId, Photo")]Post post)
        {
            if (!ModelState.IsValid) return View(post);

            if (post.Photo == null)
            {
                ModelState.AddModelError("Photo", "Photo should be added.");
                return View(post);
            }

            if (!post.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Photo type is not valid.");
                return View(post);
            }

            post.Image = post.Photo.Save("posts");

            post.CreatedAt = post.UpdatedAt = DateTime.Now;
            post.ViewCount = 0;

            _context.Posts.Add(post);
            _context.SaveChanges();

            return RedirectToAction(nameof(HomeController.Index), "Home");
            
        }

        public ActionResult Edit(int? id)
        {
            if(id == null) return HttpNotFound("Id not found.");

            var post = _context.Posts.Find(id);

            if(post == null) return HttpNotFound("Post not found.");

            return View(post);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id, Title, Content, AuthorId, Photo")]Post post)
        {
            if (!ModelState.IsValid) return View(post);

            Post postFromDb = _context.Posts.Find(post.Id);

            if(post.Photo != null)
            {
                //remove old image, Utilities method remove
                Remove(postFromDb.Image);
                //save new image
                postFromDb.Image = post.Photo.Save("posts");
            }

            postFromDb.Title = post.Title;
            postFromDb.Content = post.Content;
            postFromDb.Author = post.Author;
            postFromDb.UpdatedAt = DateTime.Now;

            _context.SaveChanges();

            return RedirectToAction("Index", "Home");
        }

        public ActionResult Delete(int? id)
        {
            if (id == null) return HttpNotFound("Id not found.");

            var post = _context.Posts.Find(id);

            if (post == null) return HttpNotFound("Post not found.");

            return View(post);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public ActionResult DeletePost(int? id)
        {
            if (id == null) return HttpNotFound("Id not found.");

            var post = _context.Posts.Find(id);

            if (post == null) return HttpNotFound("Post not found.");

            Remove(post.Image);

            _context.Posts.Remove(post);
            _context.SaveChanges();

            return RedirectToAction("Index", "Home");
        }
    }
   
}