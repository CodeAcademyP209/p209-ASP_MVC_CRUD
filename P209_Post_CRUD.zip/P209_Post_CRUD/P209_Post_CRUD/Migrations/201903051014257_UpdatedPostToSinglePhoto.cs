namespace P209_Post_CRUD.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdatedPostToSinglePhoto : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Posts", "Image", c => c.String(maxLength: 300));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Posts", "Image");
        }
    }
}
