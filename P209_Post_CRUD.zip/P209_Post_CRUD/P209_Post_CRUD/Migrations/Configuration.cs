namespace P209_Post_CRUD.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using P209_Post_CRUD.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<P209_Post_CRUD.DAL.BlogContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(P209_Post_CRUD.DAL.BlogContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.
            context.Authors.AddOrUpdate(a => new { a.Firstname, a.Lastname },
                new Author { Firstname = "Samir", Lastname = "Dadash-zade" },
                new Author { Firstname = "Yasin", Lastname = "Dadash-zade" },
                new Author { Firstname = "Eli", Lastname = "Eliyev" },
                new Author { Firstname = "Zakir", Lastname = "Qaralov" }
            );
            context.SaveChanges();
        }
    }
}
