﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

namespace P209_Post_CRUD.Utilities
{
    public static class Utilities
    {
        public static void Remove(string image)
        {
            string path = Path.Combine(HttpContext.Current.Server.MapPath("~/Uploads"), image);

            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }
    }
}